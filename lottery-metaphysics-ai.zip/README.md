# AI + Metaphysics Lottery Forecast

This Streamlit app predicts Thai lottery numbers using a hybrid of AI (Random Forest) and Chinese metaphysics (BaZi, Qi Men Dun Jia).

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Cloud

Just push this repo to GitHub and connect it to [https://streamlit.io/cloud](https://streamlit.io/cloud)
