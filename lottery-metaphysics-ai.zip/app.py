import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import random
import io
import requests
from datetime import datetime, timedelta
import sqlite3
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import math
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="AI + Metaphysics Lottery Forecast", layout="wide")
st.title("🎯 AI + Metaphysics Lottery Forecast")

st.markdown("""ระบบทำนายเลขสลากกินแบ่งรัฐบาล โดยผสมผสาน AI + ดวงจีน
- วิเคราะห์เลข 6 หลัก พร้อมแปลงเป็นธาตุ (五行)
- คำนวณคะแนน Qi Men Dun Jia + Flying Star
- จัดอันดับเลขจากความเหมาะสม
- 📍 แสดงแผนที่จุดขายหวยมงคล
- 🧭 วิเคราะห์ฤกษ์ เวลา และทิศที่เหมาะกับดวง
- 📲 พยากรณ์ล่วงหน้าเลขเด่นเฉพาะสำหรับการซื้อผ่านแอปเป๋าตังค์
""")

st.markdown("""---\n📲 **เลขเด่นสำหรับซื้อผ่านแอปเป๋าตังค์ (แบบพิเศษ)**""")
def generate_metaphysical_numbers(seed, day_element):
    rng = random.Random(seed)
    nums = []
    element_map = {
        'Water': [0,1],
        'Wood': [3,4],
        'Fire': [9],
        'Earth': [2,5,8],
        'Metal': [6,7]
    }
    good_digits = element_map.get(day_element, list(range(10)))
    while len(nums) < 10:
        candidate = ''.join([str(rng.choice(good_digits)) for _ in range(6)])
        if candidate not in nums:
            nums.append(candidate)
    return nums

st.info("กรุณาระบุวันเกิดในระบบเพื่อให้แสดงเลขเด่น")
