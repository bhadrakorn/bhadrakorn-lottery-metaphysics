mkdir -p ~/.streamlit/
echo "[server]\nheadless = true\nport = 8501\nenableCORS = false" > ~/.streamlit/config.toml
