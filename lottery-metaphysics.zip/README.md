# 🎯 AI + Metaphysics Lottery Forecast

Predict Thai lottery numbers using AI and metaphysics like BaZi and Qi Men Dun Jia.

## Deployment
- Use with Streamlit Cloud
- Main file: app.py
