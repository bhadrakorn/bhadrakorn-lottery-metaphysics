
import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import random
import requests
from datetime import datetime
import math
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="AI + Metaphysics Lottery Forecast", layout="wide")
st.title("🎯 AI + Metaphysics Lottery Forecast")
st.markdown("ระบบทำนายเลขสลากกินแบ่งรัฐบาล โดยผสมผสาน AI + ดวงจีน...")
# (คุณควรวางโค้ดเต็มจากข้อความก่อนหน้าแทนที่ตรงนี้)
